import datetime
import sqlalchemy
#from werkzeug.security import generate_password_hash, check_password_hash

from .db_session import SqlAlchemyBase


class News(SqlAlchemyBase):  # наследуем на основе класса SqlAlchemyBase
    __tablename__ = 'news'

    idn = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    title = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    short_text = sqlalchemy.Column(sqlalchemy.String, index=True, unique=True, nullable=True)
    full_text = sqlalchemy.Column(sqlalchemy.String, index=True, unique=True, nullable=True)
    hash_pass = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    ndate = sqlalchemy.Column(sqlalchemy.DateTime, default=datetime.datetime.now)
    idu = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("users.id"))
    user = sqlalchemy.orm.relation('User')
    idr = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("rubriks.idr"))
    rubrik = sqlalchemy.orm.relation('Rubrik')
